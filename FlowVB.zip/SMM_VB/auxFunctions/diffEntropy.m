function diffE = diffEntropy( r, i, j )
% Compute the difference in entropy when merging the i-th and
% j-th columns
diffE = sum( -(r(:,i).*log(r(:,i)) + ...
    r(:,j) .* log(r(:,j))) + ...
    (r(:,i)+r(:,j)) .* log(r(:,i)+r(:,j)) );
end
