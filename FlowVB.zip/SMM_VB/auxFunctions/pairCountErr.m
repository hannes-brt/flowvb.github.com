function [ errRate ] = pairCountErr( trueLabels, estimLabels )
%PAIRCOUNTERR Evaluates a clustering based on the all-pair counting method

unlabeled = trueLabels==0; % Unlabeled observations

n = length(trueLabels) - sum(unlabeled);

trueLabels = trueLabels(~unlabeled); % Skip unlabeled observations
estimLabels = estimLabels(~unlabeled);

errCount = 0; % Counts the number of errors

for i = 1:n
    for j=i:n
        sameInTrueLabels = trueLabels(i)==trueLabels(j);
        sameInEstimLabels = estimLabels(i)==estimLabels(j);
        errCount = errCount + (sameInTrueLabels ~= sameInEstimLabels);
    end
end

errRate = errCount / (n^2/2);

end

