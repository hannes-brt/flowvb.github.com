function [ vMeasure ] = vMeasure( trueLabels, estimLabels, beta )
%VMEASURE Calculates the V-measure of Rosenberg & Hirschberg (2007)

if length(trueLabels) ~= length(estimLabels)
    fprintf(2, 'Arguments must be vectors of the same length!')
end

% A(i,j) is in true cluster i and estimated to be in cluster j
A = crosstab(trueLabels, estimLabels)'; 

% Don't look at outliers (delete first row)
A(1,:) = [];

N = sum(A(:));

% Compute the homegeneity measure
homogeneity = - sum(sum( (A/N) .* log( bsxfun(@rdivide, A, sum(A, 1)) + eps ) ));
homogeneityNormalizingConstant = - sum( (sum(A, 2) / N) .* log( sum(A, 2)/N) );
if homogeneity ~= 0
    h = 1 - homogeneity / homogeneityNormalizingConstant;
else
    h = 1;
end

% Compute the completeness measure
completeness = - sum(sum( (A/N) .* log( bsxfun(@rdivide, A, sum(A, 2)) + eps ) ));
completenessNormalizingConstant = - sum( (sum(A, 1) / N) .* log( sum(A, 1)/N) );
if completeness ~= 0
    c = 1 - completeness / completenessNormalizingConstant;
else
    c = 1;
end

vMeasure = ((1 + beta)*h*c)/((beta*h)+c);

end

