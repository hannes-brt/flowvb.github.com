function e = entropy( r )
% Compute entropy given a set of responsabilities
e = -sum( sum( r .* log(r + eps) ) );
end
