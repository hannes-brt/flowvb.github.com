classdef mixStudentPrior 
    properties (GetAccess = 'private', SetAccess = 'private')
        kappa0;
        m0;
        eta0;
        gamma0;
        S0;
        nu0;
    end

    %% Public methods
    methods
        % Constructor for model. Assign vague priors for parameters.
        % Arguments: D the dimensions of the data.
        function obj = mixStudentPrior(D, K, kappa0, nu0)
            obj.kappa0 = kappa0 * ones(1,K);
            obj.m0     = zeros(1,D);
            obj.eta0   = 1;
            obj.gamma0 = 20;
            obj.S0     = 1/200*eye(D);           
            obj.nu0    = nu0;
        end
        
        % Get the prior parameters.
        function params = getParameters(obj)
            params.kappa0   = obj.kappa0;
            params.m0       = obj.m0;
            params.eta0     = obj.eta0;
            params.gamma0   = obj.gamma0;
            params.S0       = obj.S0;
            params.nu0      = obj.nu0;
        end
        
        function obj = removeClusters(obj, indices)
            obj.kappa0(indices) = [];
        end
    end
    
end