classdef mixStudentESS
    properties (GetAccess = 'private', SetAccess = 'private')
        mu;
        Sigma;
        pi;
        omega;

        N;
        D;
        K;
    end

    %% Public methods.
    methods
        % Constructor.
        function obj = mixStudentESS(N, D, K, mu, Sigma, pi)
            obj.N = N;
            obj.D = D;
            obj.K = K;

            obj.mu    = mu;
            obj.Sigma = Sigma;
            obj.pi    = pi;
            obj.omega = pi; % Assume the u's are all 1 to start.
        end

        % Update the ancillary statistics.
        function obj = updateParameters(obj, latentVariableObj, X)
            N = obj.N;
            K = obj.K;

            lv = latentVariableObj.getParameters();

            % Equation 35
            obj.omega = 1/N * sum( lv.rho .* lv.u, 1);

            % Equation 34
            obj.pi = 1/N * sum(lv.rho, 1);

            for k = 1:K
                % Equation 32
                obj.mu(k,:) = (1/(N * obj.omega(k) ) ) * ...
                    sum(bsxfun(@times, X, lv.rho(:,k) .* lv.u(:,k)));

                % Equation 33
                XC = bsxfun(@minus, X, obj.mu(k,:) );
                obj.Sigma(:,:,k) = 1/(N*obj.omega(k)) * ...
                    bsxfun(@times, XC, lv.rho(:,k).*lv.u(:,k) )' * XC;
            end
        end

        % Get the ancillary statistics.
        function params = getParameters(obj)
            params.mu    = obj.mu;
            params.Sigma = obj.Sigma;
            params.pi    = obj.pi;
            params.omega = obj.omega;
            params.K     = obj.K;
        end

        function obj = removeClusters(obj, indices)
            obj.K = obj.K - length(indices);

            obj.mu(indices,:)      = [];
            obj.Sigma(:,:,indices) = [];
            
            obj.pi(indices)    = [];
            obj.omega(indices) = [];
        end
    end

end