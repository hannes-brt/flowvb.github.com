classdef mixStudentLowerBound
    properties (GetAccess = 'private', SetAccess = 'private')
        prior;

        logDirichletConst0;
        logWishartConst0;

        N;
        D;
        K;
        
        logDirichletNormalisation0;
        logDirichletNormalisation
    end

    methods
        % Constructor
        function obj = mixStudentLowerBound(priorObj, N, D, K)
            obj.N = N;
            obj.D = D;
            obj.K = K;

            obj.prior = priorObj.getParameters();

            obj.logDirichletConst0 = obj.getLogDirichletConstant(obj.prior.kappa0);
            obj.logWishartConst0   = obj.getLogWishartConstant(D, obj.prior.gamma0, obj.prior.S0);

            obj.logDirichletNormalisation0 = gammaln( K*obj.prior.kappa0(1) );
            obj.logDirichletNormalisation  = gammaln( N + K*obj.prior.kappa0(1) );
        end

        function L = getLowerBound(obj, X, latentVariableObj, essObj, postObj)
            prior = obj.prior;
            lv    = latentVariableObj.getParameters();
            ess   = essObj.getParameters();
            post  = postObj.getParameters();

            ExpectLogPX     = obj.getExpectLogPX(X, lv, ess, post);
            ExpectLogPU     = obj.getExpectLogPU(lv, ess, post);
            ExpectLogPZ     = obj.getExpectLogPZ(lv);
            ExpectLogPTheta = obj.getExpectLogPTheta(prior, lv, ess, post);
            ExpectLogQU     = obj.getExpectLogQU(lv, ess);
            ExpectLogQZ     = obj.getExpectLogQZ(lv);
            ExpectLogQTheta = obj.getExpectLogQTheta2(lv, post);

            L = ExpectLogPX + ExpectLogPU + ExpectLogPZ + ExpectLogPTheta...
                - ExpectLogQU -ExpectLogQZ - ExpectLogQTheta;
        end

        function obj = removeClusters(obj, indices, priorObj)
            obj.K = obj.K - length(indices);

            obj.prior = priorObj.getParameters();
        end

    end

    %% Helper functions for the class.
    methods (Access = private)
        %% Function for computing normalisation constants.
        function logDirichletConst = getLogDirichletConstant(obj, kappa)
            logDirichletConst = gammaln( sum(kappa) ) - ...
                sum( gammaln(kappa) );
        end

        function logWishartConst = getLogWishartConstant(obj, D, gamma, S)
            logWishartConst = (gamma / 2) * logdet(S) -...
                (gamma * D / 2) * log(2) -...
                mvtGammaln(D, gamma/2);
        end

        %% Function for computing terms in the lower bound.
        % Compute equation 40.
        function ExpectLogPX = getExpectLogPX(obj, X, lv, ess, post)
            N = obj.N;
            D = obj.D;
            K = obj.K;

            ExpectLogPX = NaN(1,K);

            for k=1:K
                XC = bsxfun(@minus, X, post.m(k,:));
                weightedMahalDist = sum(lv.rho(:,k) .* lv.u(:,k) .* sum( XC * post.invS(:,:,k) .* XC, 2));

                ExpectLogPX(k) = ...
                    D * sum( lv.rho(:,k) .* lv.logU(:,k) ) + ...
                    N * lv.logLambdaTilde(k) * ess.pi(k) - ...
                    post.gamma(k) * weightedMahalDist - ...
                    N * D * ( ess.omega(k) / post.eta(k) );

            end

            ExpectLogPX = -(N*D/2)*log(2*pi) + 1/2 * sum(ExpectLogPX);
        end

        % Compute equation 41
        function ExpectLogPU = getExpectLogPU(obj, lv, ess, post)
            N = obj.N;
            K = obj.K;

            ExpectLogPU = NaN(1,K);

            for k=1:K
                ExpectLogPU(k) = ...
                    (N/2) * ess.pi(k) * post.nu(k) * log(post.nu(k)/2) -...
                    N * ess.pi(k) * gammaln( post.nu(k)/2 ) + ...
                    ( post.nu(k)/2 - 1) * sum( lv.rho(:,k) .* lv.logU(:,k), 1) - ...
                    (N/2) * post.nu(k) * ess.omega(k);
            end

            ExpectLogPU = sum(ExpectLogPU);
        end

        % Compute equation 42
        function ExpectLogPZ = getExpectLogPZ(obj, lv)
            K = obj.K;

            ExpectLogPZ = NaN(1,K);

            for k=1:K
                ExpectLogPZ(k) = sum(lv.rho(:,k) .* lv.logPiTilde(k));
            end

            ExpectLogPZ = sum(ExpectLogPZ);
        end

        % Compute equation 43
        function ExpectLogPTheta = getExpectLogPTheta(obj,prior, lv, ess, post)
            K = obj.K;
            D = obj.D;

            ExpectLogPTheta = NaN(1,K);

            for k=1:K
                mc = post.m(k,:) - prior.m0;

                ExpectLogPTheta(k) = ...
                    (prior.kappa0(k) - 1) * lv.logPiTilde(k) - ...
                    ( prior.eta0 * post.gamma(k) / 2 ) * (mc * post.invS(:,:,k) * mc') - ...
                    (D/2) * ( prior.eta0 / post.eta(k) ) + ...
                    (prior.gamma0 - D)/2 * lv.logLambdaTilde(k) - ...
                    (post.gamma(k)/2) * trace( prior.S0 * post.invS(:,:,k) ) - ...
                    gammaln( prior.kappa0(k) );
            end
            
            ExpectLogPTheta =...
                obj.logDirichletNormalisation0 + ...
                K*obj.logWishartConst0 -...
                (K*D)/2 * log(2*pi) + ...
                (K*D)/2 * log(prior.eta0) + ...
                sum(ExpectLogPTheta);
        end

        % Compute equation 44
        function ExpectLogQU = getExpectLogQU(obj, lv, ess)
            N = obj.N;
            K = obj.K;

            ExpectLogQU = NaN(1,K);

            for k=1:K
                ExpectLogQU(k) = ...
                    -N * gammaln( lv.alpha(k) ) * ess.pi(k) + ...
                    N * ess.pi(k) * psi( lv.alpha(k) ) * (lv.alpha(k) - 1) + ...
                    sum( lv.rho(:,k) .* log( lv.beta(:,k) ) ) - ...
                    N * ess.pi(k) * lv.alpha(k);
            end

            ExpectLogQU = sum(ExpectLogQU);
        end

        % Compute equation 45
        function ExpectLogQZ = getExpectLogQZ(obj, lv)
            ExpectLogQZ = sum( sum(lv.rho .* log(lv.rho + eps) ));
        end
        
        % Compute equation 46
        function ExpectLogQTheta = getExpectLogQTheta2(obj, lv, post)
            D = obj.D;
            K = obj.K;

            ExpectLogQTheta = NaN(1,K);

            for k=1:K
                logWishartConst = ...
                    getLogWishartConstant(obj, D, post.gamma(k), post.S(:,:,k));

                ExpectLogQTheta(k) = ...
                    (post.kappa(k) - 1) * lv.logPiTilde(k) + ...
                    (D/2) * log( post.eta(k) ) + ...
                    logWishartConst + ...
                    (post.gamma(k) - D)/2 * lv.logLambdaTilde(k) -...
                    (post.gamma(k) * D) / 2 - ....
                    gammaln( post.kappa(k) );
            end

%            logDirichletConst = obj.getLogDirichletConstant(post.kappa);
            
            ExpectLogQTheta = ...
                obj.logDirichletNormalisation - ...
                (K*D)/2 * log(2*pi) -...
                (K*D)/2 + ...
                sum(ExpectLogQTheta);
        end


    end
end