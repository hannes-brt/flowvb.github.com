classdef mixStudentPosterior
    properties (GetAccess = 'private', SetAccess = 'private')
        kappa;
        eta;
        gamma;
        m;
        S;
        invS;

        nu;
        nu0;

        N; % Number of observations.
        K; % Number of clusters.
        fzeroOptions;
        gaussian;
    end

    %% Public methods.
    methods
        function obj = mixStudentPosterior(priorObj, N, K, gaussian)
            obj.N = N;
            obj.K = K;
            obj.gaussian = gaussian;

            prior = priorObj.getParameters();

            obj.kappa = prior.kappa0;
            obj.eta   = prior.eta0 * ones(1,K);
            obj.gamma = prior.gamma0 * ones(1,K);
            obj.m     = repmat(prior.m0, K, 1);

            obj.nu = 20*ones(1,K);
            obj.nu0 = prior.nu0;

            for k = 1:K
                obj.S(:,:,k) = prior.S0;
                obj.invS(:,:,k) = inv( obj.S(:,:,k) );
            end
            

            obj.fzeroOptions = optimset('TolX', 1e-5, 'TolFun', 1e-2);
        end

        % Update the model posterior parameters.
        % Inputs: priorObj an object of the class mixStudentPrior
        %       : essObj an object of the class mixStudentESS
        %       : latentVariableObj an object of class mixStudentLatentVariables
        function obj = updateParameters(obj, priorObj, essObj, latentVariableObj, approx, initStep)
            if nargin < 6; initStep = false; end
            N = obj.N;
            K = obj.K;

            prior = priorObj.getParameters();
            ess   = essObj.getParameters();

            % Equation 27
            obj.kappa = N * ess.pi + prior.kappa0;

            % Equation 28
            obj.eta   = N * ess.omega + prior.eta0;

            % Equation 30
            obj.gamma = N * ess.pi + prior.gamma0;

            for k = 1:K
                % Equation 29
                obj.m(k,:) = (N * ess.omega(k) * ess.mu(k,:) + prior.eta0 * prior.m0) / obj.eta(k);

                % Equation 31
                scatter = (ess.mu(k,:) - prior.m0)' * (ess.mu(k,:) - prior.m0);
                obj.S(:,:,k) = N * ess.omega(k) * ess.Sigma(:,:,k) + ...
                    (N * ess.omega(k) * prior.eta0) / obj.eta(k) * scatter + ...
                    prior.S0;
                
                obj.invS(:,:,k) = inv( obj.S(:,:,k) );

                % If we put nu in here, we don't have to check whether
                % the cluster is empty in getNU().
                lv = latentVariableObj.getParameters();
                if ~initStep && ~obj.gaussian
                    obj.nu = obj.getNu(ess,lv, approx);
                else
                    obj.nu = obj.nu0 * ones(1,K);
                end
            end
        end

        % Get the posterior parameters.
        function params = getParameters(obj)
            params.kappa = obj.kappa;
            params.eta   = obj.eta;
            params.gamma = obj.gamma;
            params.m     = obj.m;
            params.S     = obj.S;
            params.invS  = obj.invS;
            params.nu    = obj.nu;
        end

        function obj = removeClusters(obj, indices, priorObj)
            obj.K = obj.K - length(indices);

            prior = priorObj.getParameters();

            obj.kappa(indices) = [];
            obj.eta(indices)   = [];
            obj.gamma(indices) = [];
            obj.m(indices,:)   = [];

            obj.nu(indices) = [];
            obj.nu0 = prior.nu0;

            obj.S(:,:,indices)    = [];
            obj.invS(:,:,indices) = [];
        end
    end

    %% Helper functions for the class.
    methods (Access = private)

        % Update nu for each class using a simple root finding search.
        function nu = getNu(obj, ess, lv, approx)
            N = obj.N;
            K = obj.K;
            options = obj.fzeroOptions;

            nu = NaN(1,K);

            for k = 1:K
                a = (1/ ( N * ess.pi(k) )) * ...
                    sum(lv.rho(:,k) .* (lv.logU(:,k) - lv.u(:,k) ) );

                % Check that the endpoints differ in sign, we can just
                % check 1+a<0 because log(nu/2)-psi(nu/2)->+inf when nu->0
                % and ->0 when nu->inf.
%                 if 1 + a < 0
%                     changeSign = true;
%                 else
%                     changeSign = false;
%                 end

                % Optimise for nu.
                if approx
                    nu(k) = - 1 / (1 + a); % order-one approximation
%                     nu(k) = (3 + sqrt(21 - 12 * a)) / (6*(1-a)); % second-order approximation
                else
                    objfun = @(nu) log(nu/2) + 1 - psi(nu/2) + a;
                     try
                        nu(k) = fzero(objfun, obj.nu(k), options);
                     catch
                         nu(k) = obj.nu0;
                     end
%                 else
%                     nu(k) = obj.nu0;
                end
            end
        end
    end
end