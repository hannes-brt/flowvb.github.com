classdef SMM_VB < handle
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Properties
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    properties (GetAccess = 'private', SetAccess = 'private')
        priorObj;               % Prior parameters
        essObj;                 % Ancilliary statistics
        latentVariableObj;      % Latent variables
        postObj;                % Posterior parameters
        lowerBound;             % Variables for the lower bound
        
        loglikHist;             % The lower bound
        
        data;                   % The data (NxD-dimensional)
        
        options;                % Options passed to the constructor
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Public Methods
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    methods
        % Constructor
        function obj = SMM_VB(data, varargin)
            [Kinit, maxIter, thresh, plotFn, verbose, kappa0, nu0, ...
                approx, remClustThresh, standardize, cutoff, gaussian,...
                restarts] = ...
                process_options(varargin,...
                'Kinit', 100, 'maxIter', 200, 'thresh', 1e-5,...
                'plotFn', [], 'verbose', true, 'kappa0', 0.001,...
                'nu0', 100, 'approx', false, 'remClustThresh', 0.01,...
                'standardize', false, 'PCAcutoff', 0, 'gaussian', false,...
                'restarts', 5);
            
            if cutoff > 0, standardize = true; end
            
            if standardize, data = standardizeCols(data); end
            
            if cutoff > 0, data = obj.PCA(data, cutoff, verbose); end
            
            if gaussian, nu0=500; end
            [N, D] = size(data);
            
            %% Initialize 3K clusters from which K will be selected randomly
            Kbig = 3*Kinit;
            [initPiBig initMuBig initSigmaBig]=SMM_VB.initKmeans(data, Kbig);
            
            %% Outer loop
            for s=1:restarts
                %% Choose random starting points
                idxInit     = randperm(Kbig);
                idxInit     = idxInit(1:Kinit);
                initPi      = initPiBig(idxInit);
                initMu      = initMuBig(idxInit, :);
                initSigma   = initSigmaBig(:,:,idxInit);
                
                %% Initialise data structures.
                priorObj{s}             = mixStudentPrior(D, Kinit, kappa0, nu0);
                latentVariableObj{s}    = mixStudentLatentVariables(N, D, Kinit);
                essObj{s}               = mixStudentESS(N, D, Kinit, initMu, initSigma, initPi);
                postObj{s}              = mixStudentPosterior(priorObj{s}, N, Kinit, gaussian);
                lowerBound{s}           = mixStudentLowerBound(priorObj{s}, N, D, Kinit);
                
                %% Do the initial M-Step
                postObj{s} = postObj{s}.updateParameters(...
                    priorObj{s},...
                    essObj{s},...
                    latentVariableObj{s},...
                    approx,...
                    true);
                
                %% Main loop
                iter = 1;
                done = false;
                while ~done
                    % E step
                    latentVariableObj{s} = ...
                        latentVariableObj{s}.updateParameters(postObj{s}, data);
                    
                    % Compute the ancillary statistics for M step
                    essObj{s} = ...
                        essObj{s}.updateParameters(latentVariableObj{s}, data);
                    
                    % Extinguish any empty clusters.
                    [priorObj{s}, latentVariableObj{s}, essObj{s}, postObj{s}, lowerBound{s}, ind] = ...
                        SMM_VB.extinguishClusters(...
                        priorObj{s},...
                        latentVariableObj{s},...
                        essObj{s},...
                        postObj{s},...
                        lowerBound{s},...
                        remClustThresh);
                    
                    % Log message
                    if ~isempty(ind) && verbose
                        fprintf(['Killed %d clusters in iteration %d. Now K=%d.\n'],...
                            [length(ind), iter, essObj{s}.getParameters().K]);
                    end
                    
                    
                    % M Step
                    postObj{s} = postObj{s}.updateParameters(priorObj{s},...
                        essObj{s},...
                        latentVariableObj{s},...
                        approx);
                    
                    % Compute the lower bound.
                    loglikHist{s}(iter) = ...
                        lowerBound{s}.getLowerBound(data, latentVariableObj{s}, essObj{s}, postObj{s});
                    
                    % Plot
                    if ~isempty(plotFn)
                        plotFn(data, postObj{s}.getParameters().kappa,...
                            postObj{s}.getParameters().m, ...
                            postObj{s}.getParameters().invS,...
                            postObj{s}.getParameters().gamma,...
                            loglikHist{s}(iter), iter);
                    end
                    
                    % Converged?
                    if iter == 1
                        converged = false;
                    else
                        converged =  convergenceTest(loglikHist{s}(iter),...
                            loglikHist{s}(iter-1),...
                            thresh);
                        
                        % Turn off the approximation as convergence slows down.
                        if loglikHist{s}(iter) - loglikHist{s}(iter-1) < 0.001
                            approx = false;
                        end
                        
                    end
                    
                    done = converged || (iter > maxIter);
                    
                    % Log-message
                    if verbose, fprintf(1, 'iteration %d, loglik = %f\n',...
                            iter, loglikHist{s}(iter)); end
                    
                    iter = iter + 1;
                end
                
                finalLogLik(s) = loglikHist{s}(end);
                
            end
            
            % Save object properties
            sBest                   = find(finalLogLik == max(finalLogLik));
            obj.priorObj            = priorObj{sBest};
            obj.essObj              = essObj{sBest};
            obj.latentVariableObj   = latentVariableObj{sBest};
            obj.postObj             = postObj{sBest};
            obj.lowerBound          = lowerBound{sBest};
            obj.loglikHist          = loglikHist{sBest};
            
            obj.data = data;
            
            obj.options.Kinit           = Kinit;
            obj.options.maxIter         = maxIter;
            obj.options.thresh          = thresh;
            obj.options.plotFn          = plotFn;
            obj.options.verbose         = verbose;
            obj.options.kappa0          = kappa0;
            obj.options.nu0             = nu0;
            obj.options.approx          = approx;
            obj.options.remClustThresh  = remClustThresh;
            obj.options.gaussian        = gaussian;
            obj.options.restarts        = restarts;
            obj.options.standardize     = standardize;
            obj.options.usePCA          = (cutoff > 0);
            obj.options.PCAcutoff       = cutoff;
            
            
        end
        
        function model = getModel(obj)
            % GETMODEL Accessor for the model structure
            essParams               = obj.essObj.getParameters();
            lvParams                = obj.latentVariableObj.getParameters();
            postParams              = obj.postObj.getParameters();
            model.K                 = essParams.K;
            model.responsibilities  = lvParams.rho;
            model.mixweight         = essParams.pi;
            model.mu                = postParams.m;
            model.Sigma             = postParams.invS;
            model.dof               = postParams.nu;
            model.gamma             = postParams.gamma;
            model.hardclusters      = SMM_VB.hardcluster(model.responsibilities);
            
            [rMerged kMerged] = SMM_VB.mergeClusters(model.responsibilities);
            model.responsibilities_merged = rMerged;
            model.K_merged = kMerged;
            model.hardclusters_merged = SMM_VB.hardcluster(rMerged);

        end
        
        function loglikHist = getLoglik(obj)
            % GETLOGLIKHIST Accessor for the log-likelihood
            loglikHist = obj.loglikHist;
        end
        
        function options = getOptions(obj)
            % GETOPTIONS Accessor for the options
            options = obj.options;
        end
        
        function crosstable = crosstab( obj, labels )
            %CROSSTAB Computes cross-tabs for the true and estimated
            %labels. Output is a table with the true clusters in the
            %columns and the estimated clusters in the rows.
            
            model = obj.getModel();
            
            KEstim      = model.K;
            trueClasses = unique(labels);
            KTrue       = length(trueClasses);
            crosstable  = NaN(KEstim, KTrue);
            
            labelsEstim = model.hardclusters;
            
            for k=1:KTrue
                for j=1:KEstim
                    crosstable(j,k) = ...
                        sum((labels==trueClasses(k)) & (labelsEstim==j));
                end
            end
        end
        
        function [ errRate ] = pairCountErr( obj, trueLabels )
            %PAIRCOUNTERR Evaluates a clustering based on the all-pair counting method
            
            estimLabels = obj.model.hardclusters;
            unlabeled = trueLabels==0; % Unlabeled observations
            
            n = length(trueLabels) - sum(unlabeled);
            
            trueLabels = trueLabels(~unlabeled); % Skip unlabeled observations
            estimLabels = estimLabels(~unlabeled);
            
            errCount = 0; % Counts the number of errors
            
            for i = 1:n
                for j=i:n
                    sameInTrueLabels = trueLabels(i)==trueLabels(j);
                    sameInEstimLabels = estimLabels(i)==estimLabels(j);
                    errCount = errCount + (sameInTrueLabels ~= sameInEstimLabels);
                end
            end
            
            errRate = errCount / (n^2/2);
            
        end
        
        function monotone = monotoneIncr( obj )
            %MONOTONEINCR Is loglikHist monotonically increasing?
            n = length(obj.loglikHist);
            monotone = all(obj.loglikHist(2:n)-obj.loglikHist(1:(n-1))>0);
        end
        
    end
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Private Methods
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    methods(Static, Access = private)
        function labels = hardcluster( r )
            %HARDCLUSTER Convert soft to hard-clustering
            
            N = size(r,1);
            maxProbIdx = @(x)find(x==max(x));
            labels = NaN(1,N);
            
            for i=1:N
                labels(i) = maxProbIdx(r(i,:));
            end
        end
        
        % Remove the empty clusters.
        function [priorObj, latentVariableObj, essObj, postObj, lowerBound, emptyClusterIndices] =...
                extinguishClusters(...
                priorObj,...
                latentVariableObj,...
                essObj,...
                postObj,...
                lowerBound,...
                remClustThresh)
            
            pi = essObj.getParameters().pi;
            
            emptyClusterIndices = find( pi < remClustThresh );
            
            if ~isempty(emptyClusterIndices)
                priorObj            = priorObj.removeClusters(emptyClusterIndices);
                latentVariableObj   = latentVariableObj.removeClusters(emptyClusterIndices);
                essObj              = essObj.removeClusters(emptyClusterIndices);
                postObj             = postObj.removeClusters(emptyClusterIndices, priorObj);
                lowerBound          = lowerBound.removeClusters(emptyClusterIndices, priorObj);
            end
        end
        
        function [initPi initMu initSigma]=initKmeans(data, K)
            setSeed(1);
            N = size(data,1);
            [initMu, initSigma, mixweight, Nk] = kmeansInitMixGauss(data, K);
            initMu = initMu';
            initPi = Nk/N;
        end
        
        function scores = PCA(data, cutoff, verbose)
            C = corr(data);
            [U S] = schur(C);
            s = diag(S);
            if verbose
                
                fprintf(['Eigenvalues of Correlation Matrix: '...
                    repmat('%3.2f ', 1, length(s)), '\n'], s);
                fprintf('Retaining %d factors\n', sum(s>cutoff));
            end
            idx = s > cutoff;
            Usmall = U(:,idx);
            scores = (Usmall' * data')';
        end
        
        function [r kOptim] = mergeClusters( r )
            q = r; % Merge a copy first
            K = size(q, 2);
            
            entropy_path(1) = entropy(q); % Entropy before merging
            merge_path = NaN(K-1,2); % Records which clusters are merged
            
            for a=1:K-1
                k = size(q,2);
                diff_entropy = zeros(k-1, k);
                for i=1:(k-1)
                    for j=(i+1):k
                        diff_entropy(i,j) = diffEntropy(q, i, j);
                    end
                end
                idx = maxidx(diff_entropy(:)); % Merging which clusters reduces entropy most?
                [iMerge jMerge] = ind2sub(size(diff_entropy), idx);
                entropy_path(a+1) = entropy_path(a) - diff_entropy(idx); % New entropy
                keepCols = setxor(1:k, [iMerge jMerge]); % Columns not to merge
                q = [q(:,keepCols) q(:,iMerge)+q(:,jMerge)]; % Merge
                merge_path(a,:) = [iMerge jMerge]; % Record which clusters were merged
            end
            
            entropy_path = fliplr(entropy_path); % Reverse the entropy_path
            
            % Fit piecewise segments to determine the best model
            RSS = NaN(1,K);
            BIC_changepoint = NaN(1,K);
            for k=2:K-1
                P = 5; % Number of Parameters in the piecewise model
                
                % Fit first segment
                y1 = entropy_path(1:k)';
                X1 = [ones(k,1) (1:k)'];
                b1 = X1\y1;
                e1 = y1 - X1*b1; % Residuals
                
                % Fit second segment
                y2 = entropy_path(k:K)';
                X2 = [ones(K-k+1,1) (k:K)'];
                b2 = X2\y2;
                e2 = y2 - X2*b2;
                
                % Combine the residuals from the segments
                eAll = [e1; e2(2:end)];
                residual_variance = var(eAll);
                
                % Compute the BIC and the residual sum of squares
                BIC_changepoint(k) = log(residual_variance) + (K*log(K))/P;
                RSS(k) = sum(eAll.^2);
                
                if K == 3 % Cannot use BIC criterium
                    slope1 = b1(2);
                    slope2 = b2(2);
                    % Compute angle between the segments
                    theta = atan(abs(slope1 - slope2)/(1 + slope1*slope2))*(180/pi);
                end
                
            end
            if K >3
                
                kOptim = minidx(RSS); % Which is the best changepoint model?
                
                % Fit model without changepoint
                P = 2; % Number of free Parameters
                X_no_chpt = [ones(K,1) (1:K)'];
                b_no_chpt = X_no_chpt\entropy_path';
                e_no_chpt = entropy_path' - X_no_chpt * b_no_chpt;
                residual_variance = var(e_no_chpt);
                BIC_no_chpt = log(residual_variance) + (K*log(K))/P;
                if BIC_changepoint(kOptim) < BIC_no_chpt, merge = true; else merge = false; end
                
            elseif K == 3
                if theta > 1, % Merge when angle is greater than 1 degree
                    kOptim = 2;
                    merge = true;
                else
                    kOptim = K;
                    merge = false;
                end
            else
                merge = false;
                kOptim = K;
            end
            
            % Merge clusters if the changepoint model is better
            if merge == true
                for a = 1:(K - kOptim)
                    k = size(r,2);
                    iMerge = merge_path(a,1);
                    jMerge = merge_path(a,2);
                    keepCols = setxor(1:k, merge_path(a,:));
                    r = [r(:,keepCols) r(:,iMerge) + r(:,jMerge)];
                end
            end
        end
        
    end
    
end