classdef mixStudentLatentVariables
    properties (GetAccess = 'private', SetAccess = 'private')
        rho;
        u;
        logU;

        logPiTilde;
        logLambdaTilde;

        N;
        D;
        K;

        alpha;
        beta;
    end

    %% Public methods.
    methods
        % Constructor.
        function obj = mixStudentLatentVariables(N, D, K)
            obj.N = N;
            obj.D = D;
            obj.K = K;

            obj.rho  = NaN(N,K);
            obj.u    = NaN(N,K);
            obj.logU = NaN(N,K);

            obj.logPiTilde = NaN(1,K);
            obj.logLambdaTilde = NaN(1,K);

            obj.alpha = NaN(1,K);
            obj.beta  = NaN(N,K);
        end

        % Update the latent variables.
        function obj = updateParameters(obj, posteriorObj, X)
            N = obj.N;
            D = obj.D;
            K = obj.K;

            post = posteriorObj.getParameters();

            obj.logPiTilde     = obj.getLogPiTilde(post);
            obj.logLambdaTilde = obj.getLogLambdaTilde(post);

            obj.alpha = (D + post.nu)/2;

            E = NaN(N,K);

            for k = 1:K
                invS = post.invS(:,:,k);

                XC = bsxfun(@minus, X, post.m(k,:) );

                Sxx = sum(XC * invS .* XC, 2);

                E(:,k) = ...
                    gammaln( ( D+post.nu(k) )/2 ) -...
                    gammaln( post.nu(k)/2 ) -...
                    (D/2)*log( post.nu(k)*pi ) +...
                    obj.logPiTilde(k) + ...
                    (1/2)*obj.logLambdaTilde(k) -...
                    ( (D + post.nu(k) )/2 ) *...
                    log(1 + (post.gamma(k)/post.nu(k)) * Sxx +...
                    D/ (post.nu(k) * post.eta(k) ) );

                obj.beta(:,k) = (post.gamma(k)/2)*Sxx +...
                    D/(2*post.eta(k)) + ...
                    post.nu(k)/2;
            end

            obj.u    = bsxfun(@rdivide, obj.alpha, obj.beta); %u(n,k) = alpha(n,k)/beta(n,k)
            obj.logU = bsxfun(@minus, psi(obj.alpha), log(obj.beta));

            logRho  = normalizeLogspace(E);
            obj.rho = exp(logRho);
        end

        function params = getParameters(obj)
            params.rho  = obj.rho;
            params.u    = obj.u;
            params.logU = obj.logU;

            params.alpha = obj.alpha;
            params.beta  = obj.beta;

            params.logPiTilde    = obj.logPiTilde;
            params.logLambdaTilde = obj.logLambdaTilde;
        end

        function obj = removeClusters(obj, indices)
            obj.K = obj.K - length(indices);

            obj.rho(:,indices)  = [];
            obj.u(:,indices)    = [];
            obj.logU(:,indices) = [];

            obj.logPiTilde(indices) = [];
            obj.logLambdaTilde(indices) = [];

            obj.alpha(indices) = [];
            obj.beta(:,indices)  = [];
        end
    end

    %% Helper functions for the class.
    methods (Access = private)
        % Compute and update logPiTilde
        function logPiTilde = getLogPiTilde(obj, post)
            logPiTilde = psi(post.kappa) - psi( sum(post.kappa) );
        end

        % Compute and update logLambdaTilde.
        function logLambdaTilde = getLogLambdaTilde(obj, post)
            D = obj.D;
            K = obj.K;

            logLambdaTilde = NaN(1,K);

            for k = 1:K
                logLambdaTilde(k) = sum( psi( 1/2 *( post.gamma(k) + 1 - [1:D]) ) ) +...
                    D*log(2) - logdet( post.S(:,:,k) );
            end
        end
    end
end